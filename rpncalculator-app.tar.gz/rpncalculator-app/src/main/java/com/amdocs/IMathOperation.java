package com.amdocs;

public interface IMathOperation {
	
	public double evaluate(double firstNumber, double secondNumber);
	
}
