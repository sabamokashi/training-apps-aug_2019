package com.amdocs;

public class Multiplication implements IMathOperation {

	public double evaluate(double firstNumber, double secondNumber) {
		return firstNumber * secondNumber;
	}

}
